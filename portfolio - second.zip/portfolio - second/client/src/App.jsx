
import './App.css'

function App() {
  return (
    <div className="portfolio">
      <nav className="navbar">
        <h2>My Portfolio</h2>
        <div>
          <a href="#home">Home</a>
          <a href="#about">About</a>
          <a href="#skills">Skills</a>
          <a href="#projects">Projects</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      <section id="home" className="hero">
        <p className="welcome">WELCOME TO MY PORTFOLIO</p>
        <img
  src="/preethu.jpg"
  alt="Preethu profile"
  className="profile-photo"
/>
      <h1>Hi, I'm <span>Preethu</span></h1>
        <h2>BCA Student | Aspiring Developer</h2>
        <p>
          I am learning programming and web development
          to build useful and creative applications.
        </p>
        <a className="btn" href="#projects">View My Projects</a>
      </section>

      <section id="about" className="section">
        <h2>About Me</h2>
        <p>
          I am a BCA student interested in software development,
          web technologies, and learning new programming skills.
          My goal is to become a professional software developer.
        </p>
      </section>

      <section id="skills" className="section">
        <h2>My Skills</h2>
        <div className="cards">
          <div className="card">HTML & CSS</div>
          <div className="card">JavaScript</div>
          <div className="card">React</div>
          <div className="card">Python</div>
          <div className="card">C Programming</div>
          <div className="card">Node.js</div>
        </div>
      </section>

      <section id="projects" className="section">
        <h2>My Projects</h2>
        <div className="cards">
          <div className="card">
            <h3>Portfolio Website</h3>
            <p>A personal website to showcase my skills.</p>
          </div>
          <div className="card">
            <h3>To-Do App</h3>
            <p>An application to manage daily tasks.</p>
          </div>
          <div className="card">
            <h3>Food Delivery App</h3>
            <p>A project for exploring food ordering features.</p>
          </div>
        </div>
      </section>

      <section id="contact" className="section">
        <h2>Contact Me</h2>
        <p>Email: your-email@example.com</p>
        <p>Location: Karnataka, India</p>
      </section>

      <footer>
        <p>© 2026 Preethu | My Portfolio</p>
      </footer>
    </div>
  )
}

export default App
