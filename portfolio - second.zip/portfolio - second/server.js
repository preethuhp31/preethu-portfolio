﻿
require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const Contact = require("./models/Contact");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(helmet());
app.use(express.json({ limit: "10kb" }));
app.use(express.urlencoded({ extended: false, limit: "10kb" }));

app.use("/api/contact", rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 10,
    standardHeaders: "draft-7",
    legacyHeaders: false
}));

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (req, res) => {
    res.json({
        status: "ok",
        message: "Portfolio server is running"
    });
});

app.post("/api/contact", async (req, res) => {
    try {
        const { name, email, subject, message } = req.body || {};

        if (
            typeof name !== "string" ||
            typeof email !== "string" ||
            typeof subject !== "string" ||
            typeof message !== "string"
        ) {
            return res.status(400).json({
                message: "Please provide all contact fields."
            });
        }

        const clean = {
            name: name.trim(),
            email: email.trim(),
            subject: subject.trim(),
            message: message.trim()
        };

        if (
            !clean.name || clean.name.length > 80 ||
            !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean.email) ||
            clean.email.length > 254 ||
            !clean.subject || clean.subject.length > 120 ||
            !clean.message || clean.message.length > 3000
        ) {
            return res.status(400).json({
                message: "Please check your details and try again."
            });
        }

        await Contact.create(clean);

        res.status(201).json({
            message: "Thank you! Your message has been saved."
        });
    } catch (error) {
        console.error("Contact form error:", error.message);
        res.status(500).json({
            message: "Unable to save your message. Please try again later."
        });
    }
});

app.get("/{*path}", (req, res, next) => {
    if (req.path.startsWith("/api/")) {
        return res.status(404).json({ message: "API route not found." });
    }

    res.sendFile(path.join(__dirname, "public", "index.html"));
});

async function startServer() {
    if (!process.env.MONGODB_URI) {
        throw new Error("MONGODB_URI is missing from the .env file.");
    }

    await mongoose.connect(process.env.MONGODB_URI);
    console.log("MongoDB connected successfully.");

    app.listen(PORT, () => {
        console.log(`Portfolio running at http://localhost:${PORT}`);
    });
}

startServer().catch((error) => {
    console.error("Unable to start server:", error.message);
    process.exit(1);
});

